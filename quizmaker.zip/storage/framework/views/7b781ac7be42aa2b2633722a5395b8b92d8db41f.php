<!DOCTYPE html>
<html lang="en-us" class="lang-en">
<table cellpadding="0" cellspacing="0" style="border-collapse: collapse; font: 13px Open Sans, sans-serif;"
       width="100%">
    <tbody>
    <tr>
        <td align="center" valign="top">
            <table cellpadding="0" cellspacing="0" style="border-collapse: collapse; font: 13px Open Sans, sans-serif;"
                   width="600">
                <tbody align="left">
                <tr align="left">
                    <td>
                        <table cellpadding="0" cellspacing="0"
                               style="border-collapse: collapse; font: 13px Open Sans, sans-serif;">
                            <tbody>
                            <tr style="height: 20px">
                                <td> <span style="font: 13px Open Sans, sans-serif; line-height: 20px">
                            This is an automatically generated assessment result of your test quiz. this email is generate from the test results and sent from the email server.</span>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <br>
                        <table cellpadding="0" cellspacing="0"
                               style="border-collapse: collapse; font: 13px Open Sans, sans-serif;">
                            <tbody>
                            <tr style="height: 20px">
                                <td>Name&nbsp;</td>
                                <td><?php echo e($details['data']->user_name); ?></td>
                            </tr>
                            <tr style="height: 20px">
                                <td>User Email&nbsp;</td>
                                <td><a href="mailto:<?php echo e($details['data']->user_email); ?>" target="_blank"
                                       rel="noopener noreferrer"><?php echo e($details['data']->user_email); ?></a>
                                </td>
                            </tr>
                            
                            
                            
                            
                            
                            <tr style="height: 15px; font-size: 1px">
                                <td colspan="2">&nbsp;
                                </td>
                            </tr>
                            <tr style="height: 20px">
                                <td>Date/Time&nbsp;</td>
                                <td><b><?php echo e($details['exam_date_time']); ?></b></td>
                            </tr>
                            <tr style="height: 20px">
                                <td>Answered:&nbsp;</td>
                                <td><strong><?php echo e($details['data']->exam_answered); ?> /
                                        <?php echo e($details['data']->exam_question_count); ?></strong></td>
                            </tr>
                            <tr style="height: 20px">
                                <td>Your Score&nbsp;</td>
                                <td><strong><?php echo e($details['data']->exam_user_score); ?>

                                        / <?php echo e($details['data']->exam_passing_score); ?>

                                        (<?php echo e(number_format(intval($details['data']->exam_user_score) / intval($details['data']->exam_passing_score), 2, '.', '')); ?>

                                        %)</strong></td>
                            </tr>
                            <tr style="height: 20px; display: table-row;">
                                <td>Passing Score&nbsp;
                                </td>
                                <td><strong><?php echo e($details['data']->exam_passing_score); ?></strong></td>
                            </tr>
                            
                            
                            
                            
                            
                            <tr style="height: 20px">
                                <td>Result&nbsp;</td>
                                <td><strong><b><span
                                                style="<?php echo e($details['data']->result == 'Pass' ? 'color: #09a23f' : 'color: #e90b0b'); ?>"><b><?php echo e($details['data']->result); ?></b></span></b></strong>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                        <br>&nbsp;
                    </td>
                </tr>
                <?php $__currentLoopData = $details['data']->quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($question['question_result'])): ?>

                        <?php if($question['question_result'] == 'Survey'): ?>
                            <tr align="left">
                                <td style="font: 13px Open Sans;padding-bottom:36px">
                      <span style="line-height: 12px"><b>Question
                          <?php echo e(intval($question['quizId']) + 1); ?> <span style="color:#5B9BD5">Survey</span></b></span><br>
                                    <span><b><?php echo e($question['question_content']); ?><br></b></span><br>
















                                    <br>
                                </td>
                            </tr>
                        <?php else: ?>
                            <tr align="left">
                                <td style="font: 13px Open Sans;padding-bottom:36px">
                      <span style="line-height: 12px"><b>Question
                          <?php echo e(intval($question['quizId']) + 1); ?> <span
                                  style="<?php echo e($question['question_result'] == 'Correct' ? 'color:#70AD47' : 'color:#CD1212'); ?>"><?php echo e($question['question_result']); ?></span></b></span><br>
                                    <span
                                        style="line-height: 20px">Points:&nbsp;<?php echo e($question['question_user_point']); ?>/<?php echo e($question['question_point']); ?>&nbsp;&nbsp;|&nbsp;&nbsp;Attempts:&nbsp;<?php echo e($question['question_user_attempts']); ?>/<?php echo e($question['question_attempts']); ?></span>
                                    <br><?php echo $question['question_content']; ?><br>
                                    <table style="width:100%;border-collapse:collapse">
                                        <tbody>
                                        <?php if(isset($question['question_user_answer'])): ?>
                                            <tr style="background-color:#F3F3F3">
                                                <td style="border: 1px solid #E0E0E0;padding:5px">
                                                    User Answer
                                                </td>
                                                <td style="border: 1px solid #E0E0E0;padding:5px">
                                                    Correct Answer
                                                </td>
                                            </tr>
                                            <?php for($i = 0; $i < count($question['question_user_answer']); $i++): ?>
                                                <tr>
                                                    <td style="border: 1px solid #E0E0E0;padding:5px">
                                                        <?php echo e($question['question_user_answer'][$i]); ?>

                                                    </td>
                                                    <td style="border: 1px solid #E0E0E0;padding:5px">
                                                        <?php echo e($question['question_correct_answer'][$i]); ?>

                                                    </td>
                                                </tr>
                                            <?php endfor; ?>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                    <br>
                                    <span><b>Feedback:</b><?php echo e($question['question_feedback']); ?></span>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </td>
    </tr>
    </tbody>
</table>

</html>
<?php /**PATH D:\Source\laravel\quizmaker\resources\views/emails/quizResultMail.blade.php ENDPATH**/ ?>