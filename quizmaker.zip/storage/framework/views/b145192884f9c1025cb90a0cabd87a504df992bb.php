<?php $__env->startSection('content'); ?>
    <div id="main">

        <div id="content" class="full">
            <div class="post manage_users">
                <div class="content_header">
                    <div class="content_header_title">
                        <div style="float: left">
                            <h2>User Management</h2>
                            <p>Create, edit and manage users permissions</p>
                        </div>

                        <div style="float: right;margin-right: 5px">
                            <a href="<?php echo e(route('users.create')); ?>" id="button_add_user" class="bb_button bb_small bb_green">
                                <i class="fas fa-plus" style="font-size: 12px;padding-right: 5px;"></i>Create New User!
                            </a>
                        </div>
                        <div style="clear: both; height: 1px"></div>
                    </div>

                </div>


                <div class="content_body">

                    <div id="entries_actions" class="gradient_red">
                        <ul>
                            <li>
                                <a id="user_delete" href="#"><i class="fas fa-trash" style="font-size: 16px;display: block;"></i>Delete</a>
                            </li>
                            <li>
                                <div class="vline_separator" style="height: 35px;margin-top:5px"></div>
                            </li>
                            <li>
                                <a id="user_suspend" href="#"><i class="fas fa-exclamation-triangle" style="font-size: 16px;display: block;"></i>Suspend</a>
                            </li>
                        </ul>
                        <img id="entries_actions_arrow" src="images/icons/29.png"
                             style="position: absolute;left:5px;top:100%">
                    </div>

                    
                    
                    
                    
                    
                    
                    


                    <div style="clear: both"></div>

                    

                    
                    
                    
                    
                    
                    
                    
                    

                    


                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    
                    

                    
                    

                    


                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    

                    <a id="entries_container">
                        <table width="100%" cellspacing="0" cellpadding="0" border="0" id="entries_table">
                            <thead>
                            <tr>
                                <th class="me_action" scope="col"><input type="checkbox" value="1" name="col_select"
                                                                         id="col_select"></th>
                                <th class="me_number" scope="col">#</th>
                                <th scope="col">
                                    <div title="Name">Name</div>
                                </th>
                                <th scope="col">
                                    <div title="Email">Email</div>
                                </th>
                                <th scope="col">
                                    <div title="Admin Privileges">Admin Privileges</div>
                                </th>
                                <th scope="col">
                                    <div title="Status">Status</div>
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(auth()->user()->id != $user->id): ?>
                                    <tr id="row_<?php echo e($user->id); ?>">
                                        <td class="me_action"><input class="row_checkbox" type="checkbox"
                                                                     id="checkbox_<?php echo e($user->id); ?>"
                                                                     name="checkbox_<?php echo e($user->id); ?>"
                                                                     value="<?php echo e($user->id); ?>"></td>
                                        <td class="me_number"><?php echo e($user->id); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('/users')); ?>/<?php echo e($user->id); ?>/edit"><?php echo e($user->name); ?></a>
                                        </td>
                                        <td>
                                            <div><?php echo e($user->email); ?></div>
                                        </td>
                                        <td>
                                            <div>
                                                <?php if($user->role): ?>
                                                    Administrator
                                                <?php else: ?>
                                                    Student
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="active_col">
                                            <?php if($user->active): ?>
                                                Active
                                            <?php else: ?>
                                                Suspend
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div style="width: 100%; height: 20px;"></div>


                    <!--                <div id="me_sort_option">-->
                    <!--                    <label class="description" for="me_sort_by">Sort By ⇢ </label>-->
                    <!--                    <select class="element select" id="me_sort_by" name="me_sort_by">-->
                    <!--                        <optgroup label="Ascending">-->
                    <!--                            <option value="user_id-asc">User ID</option>-->
                    <!--                            <option value="user_fullname-asc">Name</option>-->
                    <!--                            <option value="user_email-asc">Email</option>-->
                    <!--                            <option value="priv_administer-asc">Admin Privileges</option>-->
                    <!--                            <option value="status-asc">Status</option>-->
                    <!--                        </optgroup>-->
                    <!--                        <optgroup label="Descending">-->
                    <!--                            <option selected="selected" value="user_id-desc">User ID</option>-->
                    <!--                            <option value="user_fullname-desc">Name</option>-->
                    <!--                            <option value="user_email-desc">Email</option>-->
                    <!--                            <option value="priv_administer-desc">Admin Privileges</option>-->
                    <!--                            <option value="status-desc">Status</option>-->
                    <!--                        </optgroup>-->
                    <!--                    </select>-->
                    <!--                </div>-->

                </div> <!-- /end of content_body -->

            </div><!-- /.post -->
        </div><!-- /#content -->

        <div id="dialog-warning" title="Error Title" class="buttons" style="display: none">
            <span class="icon-bubble-notification"></span>
            <p id="dialog-warning-msg">
                Error
            </p>
        </div>
        <div id="dialog-confirm-user-delete" title="Are you sure you want to delete selected users?" class="buttons"
             style="display: none">
            <span class="icon-bubble-notification"></span>
            <p id="dialog-confirm-user-delete-msg">
                This action cannot be undone.<br>
                <strong id="dialog-confirm-user-delete-info">The user will be deleted permanently and no longer has
                    access
                    to MachForm.</strong><br><br>

            </p>
        </div>
        <div id="dialog-confirm-user-suspend" title="Are you sure you want to suspend selected users?" class="buttons"
             style="display: none">
            <span class="icon-bubble-notification"></span>
            <p id="dialog-confirm-user-suspend-msg">

                <strong id="dialog-confirm-user-suspend-info">The user will be suspended and no longer has access to
                    MachForm.</strong><br><br>

            </p>
        </div>

        <div class="clear"></div>

    </div>
    <script src="<?php echo e(asset('js/user_crud.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Source\laravel\quizmaker\resources\views/users/index.blade.php ENDPATH**/ ?>