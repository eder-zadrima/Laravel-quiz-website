Numeric Quiz
