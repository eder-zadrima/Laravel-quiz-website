Hotspot Quiz Form View
